import{b as r}from"./_baseUniq-BkFUk1Tw.js";var e=4;function a(o){return r(o,e)}export{a as c};
