import{ar as o,as as s}from"./index-D61laKn8.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
