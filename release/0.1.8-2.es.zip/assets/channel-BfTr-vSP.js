import{ar as o,as as s}from"./index-Dm5493OQ.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
