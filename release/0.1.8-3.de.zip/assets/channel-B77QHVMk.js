import{ar as o,as as s}from"./index-BbIJu7RF.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
